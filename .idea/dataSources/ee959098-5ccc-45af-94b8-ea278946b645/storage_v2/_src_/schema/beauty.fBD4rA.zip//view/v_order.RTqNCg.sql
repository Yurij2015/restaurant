create definer = root@localhost view v_order as
select `o`.`id`        AS `id`,
       `o`.`clientid`  AS `clientid`,
       `o`.`salonid`   AS `salonid`,
       `o`.`date`      AS `date`,
       `o`.`time`      AS `time`,
       `o`.`price`     AS `price`,
       `o`.`masterid`  AS `masterid`,
       `o`.`serviceid` AS `serviceid`,
       `o`.`billnum`   AS `billnum`,
       `o`.`kkmid`     AS `kkmid`,
       `o`.`billdate`  AS `billdate`,
       `c`.`name1`     AS `cname1`,
       `c`.`name2`     AS `cname2`,
       `c`.`name3`     AS `cname3`,
       `e`.`name1`     AS `ename1`,
       `e`.`name2`     AS `ename2`,
       `e`.`name3`     AS `ename3`,
       `s`.`address`   AS `salon`,
       `v`.`name`      AS `servicename`,
       `v`.`price`     AS `serviceprice`,
       `v`.`duration`  AS `duration`
from ((((`beauty`.`order` `o` left join `beauty`.`user` `c` on (`o`.`clientid` = `c`.`id`)) left join `beauty`.`user` `e` on (`o`.`masterid` = `e`.`id`)) left join `beauty`.`salon` `s` on (`o`.`salonid` = `s`.`id`))
         left join `beauty`.`service` `v` on (`o`.`serviceid` = `v`.`id`));

