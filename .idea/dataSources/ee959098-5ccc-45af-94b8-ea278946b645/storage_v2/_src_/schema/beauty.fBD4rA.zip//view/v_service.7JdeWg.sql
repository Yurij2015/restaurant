create definer = root@localhost view v_service as
select `s`.`id`       AS `id`,
       `s`.`salonid`  AS `salonid`,
       `s`.`groupid`  AS `groupid`,
       `s`.`name`     AS `name`,
       `s`.`price`    AS `price`,
       `s`.`duration` AS `duration`,
       `g`.`name`     AS `group`,
       `p`.`address`  AS `salon`
from ((`beauty`.`service` `s` left join `beauty`.`servicegroup` `g` on (`s`.`groupid` = `g`.`id`))
         left join `beauty`.`salon` `p` on (`s`.`salonid` = `p`.`id`))
order by `p`.`address`, `g`.`name`;

