create definer = root@localhost view v_masterservice as
select `ms`.`id`        AS `id`,
       `ms`.`serviceid` AS `serviceid`,
       `ms`.`masterid`  AS `masterid`,
       `ms`.`salonid`   AS `salonid`,
       `u`.`name1`      AS `name1`,
       `u`.`name2`      AS `name2`,
       `u`.`name3`      AS `name3`,
       `s`.`address`    AS `address`,
       `v`.`name`       AS `service`,
       `v`.`price`      AS `price`,
       `v`.`duration`   AS `duration`
from (((`beauty`.`masterservice` `ms` left join `beauty`.`user` `u` on (`ms`.`masterid` = `u`.`id`)) left join `beauty`.`salon` `s` on (`ms`.`salonid` = `s`.`id`))
         left join `beauty`.`service` `v` on (`ms`.`serviceid` = `v`.`id`));

